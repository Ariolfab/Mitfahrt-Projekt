package demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TimetableWeekdayID implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;
    @Column(insertable=false, updatable=false)
    private Integer user_id;
    @Column(insertable=true, updatable=true)
    private Integer weekday;


}
