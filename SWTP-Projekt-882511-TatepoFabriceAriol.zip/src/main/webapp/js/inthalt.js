
var meinArray= [];

window.onload = function() {
	let token = sessionStorage.getItem('loginToken');

	if (token != null) {
		setVisibilityHeader(true);
		setVisibility("find-ride-container", false);
		hidenAsideElement();
	}
	else {
		setVisibility("find-ride-container", true);
		setVisibilityHeader(false);
		//hidenAsideElement();
		hidenStundenplanElement();
	}
    initMap();

};

let myMap;
  let latitude;
let longitude;

latitude = 49.250723;
longitude = 7.377122;

function initMap() {
    myMap = L.map('map-container').setView([49.250723, 7.377122], 12);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>, <a href="https://www.flaticon.com/free-icons/address" title="address icons">Address icons created by DinosoftLabs - Flaticon</a>',
        maxZoom: 18, // max. possible 23
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
    }).addTo(myMap);

    userMarker(latitude,longitude);
}



/////////////////////////////////////////////Maker fängt an//////////////////////////////////////////7

function userMarker(longitude,latitude){
	let marker = L.marker([latitude, longitude]).addTo(myMap);
	
	marker.on('click',event=>changeColor(event));


}

function changeColor(event) {

}

function firstUser(longitude,latitude){

	var meinIcon = L.icon({
		iconUrl:'/imgs/home-location.png',
		iconSize:[50,55]
	});

	L.marker([latitude, longitude],{icon:meinIcon}).addTo(myMap);

}
/////////////////////////////////////////////////////////////////


function setVisibility(elementId, visible) {
	const x = document.querySelector("#stundenPlan");
    const y = document.getElementById(elementId);
    
    if(visible === true) {
        y.classList.remove("hidden");
    } else {
        y.classList.add("hidden")
		x.classList.add("hidden");
		showMap();
    }
}
//Set Visibility von Element in Header

function setVisibilityHeader(visible) {

    const x = document.querySelector("#hiddenBeforLogin1");
    const y = document.querySelector("#hiddenBeforLogin2");
    
    //Login and Register Button selected
    const z = document.querySelector("#hiddenAfterLogin1");
    const w = document.querySelector("#hiddenAfterLogin2");
    
    if(visible === true) {
        x.classList.remove("hidden");
        y.classList.remove("hidden");
        
        //Login and Register Button Element Hidden
        z.classList.add("hidden");
        w.classList.add("hidden");
    } else {
        x.classList.add("hidden")
        y.classList.add("hidden")
        
        //Login and Register Button Element Show
        z.classList.remove("hidden");
        w.classList.remove("hidden");
    }
}

//Visibility von Studenplan

function setVisibilityStundenPlanElement(visible){

	const x = document.querySelector("#stundenplan");
	const y = document.querySelector("#map-container");
	const z = document.querySelector("#asideElement");
	
	if(visible === false){
		x.classList.remove("hidden");
		y.classList.remove("hidden");
		z.classList.remove("hidden");
	}else{
		x.classList.add("hidden");
		y.classList.add("hidden");
		z.classList.add("hidden");
	}
}
// get Element mit Funktionsereignis
function getStundenPlanFormular(){
	
	document.querySelector("#asideElement").style.display="none";
	let token = sessionStorage.getItem('loginToken');
	const x = document.querySelector("#stundenPlan");
	const y = document.querySelector("#map-container");
	
	if(token != null){
		x.classList.remove("hidden");
		y.classList.add("hidden");
	}
	
}

//show form-aside
function getAsideElement(){
	const x = document.querySelector("#asideElement");
	x.classList.remove("hidden");
}

//Get Element Mitfarergelegenheit
function getMitfarergelegenheitenFormx(){
	
	document.querySelector("#asideElement").style.display="block";
	let token = sessionStorage.getItem('loginToken');
	const elt = document.querySelector("#find-ride-container");
	const elt1 = document.querySelector("#stundenPlan");
	const elt2 = document.querySelector("#map-container");
	
	if(token != null){
		elt.classList.remove("hidden");
		
		elt1.classList.add("hidden");
		elt2.classList.remove("hidden");
	}
}

//Get Element von mitFahrengelegenheit

 function getMitfarergelegenheitenForm1(){
	let token = sessionStorage.getItem('loginToken');
}

//Hiden asside 
 function hidenAsideElement(){
	const elt1 = document.querySelector("#asideElement");
	elt1.classList.add("hidden");
}

//Hidden Stundenplan
 function hidenStundenplanElement(){
	const elt = document.querySelector("#stundenPlan");
	elt.classList.add("hidden");
}

//Show map
 function showMap(){
	const elt = document.querySelector("#map-container");
	elt.classList.remove("hidden");
}

//Get Form neuer User Registrieren
 function neurUserRegistrieren(){
	var registerForm = document.getElementById("neuUserRegister");
	document.querySelector("#neuUserRegister").style.display = "block";
}

// Hidden Form neuer User register
  function abbrechen(){
	document.querySelector("#neuUserRegister").style.display = "none";
}

/////////////////////////////////////////UserId/////////////////////////////////////////////////////////////////////////////////////////////////////////////
  function getUserInfo(userId) {

	return fetch("demo/access/userInfo", {
		method: 'get',
		headers: {
			'Content-type': 'application/json'
		}
	});
}

  var redIcon = L.icon({
	iconUrl: "./icon/marker-icon-red.png",
	shadowUrl: "./icon/marker-shadow.png",
	iconSize: [25,41],
	iconAnchor: [12,41],
	popupAnchor: [1,-34],
	shadowSize: [41,41],
});

  var blueIcon = L.icon({
	iconUrl: "./icon/marker-icon-blue.png",
	shadowUrl: "./icon/marker-shadow.png",
	iconSize: [25,41],
	iconAnchor: [12,41],
	popupAnchor: [1,-34],
	shadowSize: [41,41],
});

//<!-- suchen von mitfahrt anfang -->

      function suchen(){
	  var counter1 =0;
    
	let token = sessionStorage.getItem('loginToken');

	var fahrt = document.getElementById("fahrt").value;
	var hinfahrt = document.getElementById("ruckfahrt").value;
	var hinruckfahrt = document.getElementById("hinruckfahrt").value;
	var distance = document.getElementById("distance").value;
	var weeks = document.getElementById("weeks").value;
	var time = document.getElementById("time").value;

	fetch('demo/user?distance='+ distance + "&token="+ token, {
		method: 'get',
		headers: {
			'Content-type': 'application/json'
		},
	})
		.then(response => response.json())
		.then(data => {
			console.log(data);
		for (let i=0;i<data.length;i++){
	

				if (data[i].position.latitude != sessionStorage.getItem("current_user_latitude") && data[i].position.longitude != sessionStorage.getItem("current_user_longide")){
					var maker = L.marker([data[i].position.latitude, data[i].position.longitude],{
						icon: blueIcon
					}).addTo(myMap);
					meinArray.push(maker);
					for (element of meinArray){
				element.on('click',event=>changeIcon(event,data,maker))
			}	
				}
				var mytable = document.getElementById("myTable");
				//User Infos
				var userName = data[i].username + " "+ data[i].lastname;
				var userEmail = data[i].email;
				var userAdresse = data[i].street +""+data[i].streetNumber
					+", "+data[i].zip+ " "+data[i].city;
					var pos= data[i].position.latitude;

				var row = `<div id="myId`+counter1+`"` + `style="background-color:white;font-size:10px;margin-top: 2px;   display: grid;row-gap: 50px;grid-template-columns: auto auto auto;padding: 5px;">
                <div style="border: 1px solid rgba(0, 0, 0, 0);
							  padding: 10px;
							  font-size: 10px;
							  text-align: center;">
                    <img alt="" src="imgs/profile-2.png" style="height:50px;width:50px;">
                </div>
                <div style="border: 1px solid rgba(0, 0, 0, 0);
					  padding: 10px;
					  font-size: 10px;
					  text-align: center;">
                    <table>
                    <tr>
                        <td>${userName}</td>
   
                    </tr>
                    <tr><td>${userEmail}</td></tr>
                    <tr><td>${userAdresse}</td></tr>
                    <tr><td id="newId`+counter1+`"` + `>${pos}</td></tr>
                    </table>
                </div>
            </div>`;
				mytable.innerHTML += row;
				counter1++;
				console.log(data[i].position.latitude);

			} 
			console.log("Login Token " + data.token);

		})
		.catch((error) => {
			console.error('Error:', error);
			sessionStorage.removeItem('loginToken');
			document.querySelector("#loginError").innerHTML = "  ein Fehler ist aufgetreten , bitte probieren sie es noch mal!";
		});

}
 function changeIcon(event,data,element) {
	console.log(event.latlng);
	console.log(event.latlng.lat);
	
		let i=0;
			while( i<meinArray.length){
				if(meinArray[i].getLatLng() === event.latlng){
		var Div=document.getElementById("myId"+i);
	
		console.log(event.latlng.lat);
		var userName = data[i].username + " "+ data[i].lastname;
				var userEmail = data[i].email;
				var userAdresse = data[i].street +""+data[i].streetNumber
					+", "+data[i].zip+ " "+data[i].city;
					var pos= data[i].position.latitude;
					Div.innerHTML= `<div style="background-color:#d8d8d8;font-size:10px;margin-top: 2px;   display: grid;row-gap: 50px;grid-template-columns: auto auto auto;padding: 5px;">
                <div style="border: 1px solid rgba(0, 0, 0, 0);
							  padding: 10px;
							  font-size: 10px;
							  text-align: center;">
                    <img alt="" src="imgs/profile-2.png" style="height:50px;width:50px;">
                </div> <div style="border: 1px solid rgba(0, 0, 0, 0);
					  padding: 10px;
					  font-size: 10px;
					  text-align: center;">
                    <table>
                    <tr>
                        <td>${userName}</td>
                      </tr>
                    <tr><td>${userEmail}</td></tr>
                    <tr><td>${userAdresse}</td></tr>
                    <tr><td>${pos}</td></tr>
                    </table>
                </div>
            </div>`;
	L.marker([event.latlng.lat, event.latlng.lng],{
		icon: redIcon
	}).addTo(myMap);
				}
	i++;	
	}
		}