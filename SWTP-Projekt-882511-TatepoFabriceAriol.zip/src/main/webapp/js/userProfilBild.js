



document.querySelector("#profilbild").addEventListener("change",function () {
		const reader = new FileReader();

		reader.addEventListener("load",()=>{
			 console.log(reader.result);

			 document.getElementById("imageP").innerHTML = `<img  width="100" height="100"  src="${reader.result}" alt=""/>`;

			 sessionStorage.setItem("user-image",reader.result)


			if (sessionStorage.getItem("user-image") != null){
				document.getElementById("userImage-1").innerHTML = `<img  width="30" height="30"  src="${reader.result}" alt=""/>`;

			}
		})
		reader.readAsDataURL(this.files[0]);
	})